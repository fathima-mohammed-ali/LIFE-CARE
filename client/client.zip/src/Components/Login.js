import React, { useState } from 'react'
import { TextField, InputAdornment, Box,Button } from '@mui/material';
import {Mail , Lock } from '@mui/icons-material';
import './Login.css'
import axios from 'axios'

export default function Login() {


   

    const [loginInfo, setLoginInfo] = React.useState({    
        email: "",
        password: "",
       
    })
    const inputchange = (event) => {
        const { name, value } = event.target
        setLoginInfo({ ...loginInfo, [name]: value })
    }

    const [formErrors, setFormErrors] = useState({});
    const [isSubmit, setIsSubmit] = useState({});
    
    const validate = (values) => {
        var error = {}
        if (!values.email) {
            error.email = "enter your Mail"
        }
        if (!values.password) {
            error.Password = "enter your Password"
        }
    return error
    }

    const submit = (e) => {
       
        e.preventDefault();
        setFormErrors(validate(loginInfo))
        console.log("formErrors", formErrors);
        setIsSubmit(true)
        if (Object.keys(formErrors).length === 0 && isSubmit) {

            axios.post("http://localhost:4000/login/login",loginInfo)
            .then((response)=>{
              console.log(response);
            })

        }
    }
    return (
        <>
            <section>
                <div className='container'>
                    <div className='row'>
                        <div className='col-lg-12 col-md-12 col-12'>
                            <h3 className='Login-table'>Login</h3>
                            <form className='Login-form'>
                                <Box id='mail-box'>
                                    <TextField
                                        id="input-with-icon-textfield"
                                        name='email'
                                        label="Enter Your Mail"
                                        onChange={inputchange}
                                        InputProps={{
                                            startAdornment: (
                                                <InputAdornment position="start">
                                                    <Mail />
                                                </InputAdornment>
                                            ),
                                        }}
                                        variant="outlined"
                                    />
                                </Box>

                                <Box id='password-box'>
                                    <TextField
                                        id="input-with-icon-textfield"
                                        name='password'
                                        label="Enter Your Password"
                                        onChange={inputchange}
                                        InputProps={{
                                            startAdornment: (
                                                <InputAdornment position="start">
                                                    <Lock />
                                                </InputAdornment>
                                            ),
                                        }}
                                        variant="outlined"
                                    />
                                </Box>

                                <Button onClick={submit} sx={{ marginBottom: 3, backgroundColor: 'green' }} variant="contained">Sign In</Button>


                            </form>

                        </div>
                    </div>
                </div>
            </section>


        </>
    )
}
