import logo from './logo.svg';
import './App.css';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import Register from './Pages/Register';
import DoctorRegPage from './Pages/DoctorRegPage';
import LoginPage from './Pages/LoginPage';
import Home from './Pages/Home';
import About from './Components/About';
import NurseRegpage from './Pages/NurseRegpage';
import PatientRegPage from './Pages/PatientRegPage';

function App() {
  return (
    <>
    <BrowserRouter>
    <Routes>
      <Route path='/' element={<Home/>}/>
      <Route path='/aboutus' element={<About/>}/>
      <Route path='/' element={<Home/>}/>
      <Route path='/view-register'  element={<Register/>}/>
      <Route path='/register/view-doctor' element={<DoctorRegPage/>}/>
      <Route path='/register/view-nurse' element={<NurseRegpage/>}/>
      <Route path='/register/view-patient' element={<PatientRegPage/>}/>
      <Route path='/login' element={<LoginPage/>}/>

    </Routes>
    </BrowserRouter>
    </>
        
  );
}

export default App;
